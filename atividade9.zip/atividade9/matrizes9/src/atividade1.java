public class atividade1 {
    public static void main(String[] args) {
        String [][] sala =  new String[2][3];

        sala[0][0] = "Notebook Dell";
        sala[0][1] = "Macbook Pro";
        sala[0][2] = "PC Positivo";

        sala[1][0] = "Tablet Ipad";
        sala[1][1] = "Notebook HP";
        sala[1][2] = "PC gamer";

        System.out.println("O computador da mesa [1][0] é o " + sala[1][0]);

    }
}
