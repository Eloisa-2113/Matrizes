import java.io.PrintWriter;

public class Test {
    public static void main(String[] args) throws Exception {
    String[][] playlist = new String[3][2];

    playlist[0][0] = "Life goes on";                               playlist[0][1] = "BTS ";
    playlist[1][0] = "Take me home";                               playlist[1][1] = "John Denver";
    playlist[2][0] = "Quase sem querer";                           playlist[2][1] = "Legião Urbana";

        PrintWriter graver = new PrintWriter("minha_playlist2.csv");

        graver.println(" Artista; Musica");

        for (int i = 0; i < 3; i++) {
            System.out.println(playlist[i][0] + ";" + playlist[i][1]);
            graver.println(playlist[i][0] + ";" + playlist[i][1]);

        }


        // consegui concertar -Daniel
        graver.close();


        System.out.println("Playlist salva!! Abra o arquivo 'minha_playlist.csv' no Excel");

}
}
