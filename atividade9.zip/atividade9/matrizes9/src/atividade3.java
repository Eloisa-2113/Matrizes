import java.io.PrintWriter;
public class atividade3 {
    public static void main(String[] args) throws Exception {

        String[][]boletim = new String[3][2];
        boletim [0][0]= "Ana";                     boletim [0][1]= "10.0";
        boletim [1][0]= "Bruno";                   boletim [1][1]= "7.0";
        boletim [2][0]= "Carla";                   boletim [2][1]= "7.0";
        //Criar arquivo em CSV

        PrintWriter gravar = new PrintWriter("notas.csv");

        //Organizar a planilha
        gravar.println("Aluno;Nota");

        for (int i = 0; i< 3; i++){

            gravar.println(boletim[i][0] + ";" + boletim [i][1]);

        }

        gravar.close();

        System.out.println("Planilha 'notas.csv' gerada!!  ");


    }
}
