public class atividade2 {
    public static void main(String[] args) {
        String [][] feed = new String[5][3];

        feed [0][0] = "Foto da praia 🏖️";
        feed [1][2] = "Foto do por do sol 🌞";

        System.out.println("A foto selecionada é " + feed[1][2]);
    }
}
